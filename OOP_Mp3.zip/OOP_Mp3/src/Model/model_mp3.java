package Model;

public class model_mp3 {
	private String word;
	private String e_word;
	
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public String getE_word() {
		return e_word;
	}
	public void setE_word(String e_word) {
		this.e_word = e_word;
	}
	
}
